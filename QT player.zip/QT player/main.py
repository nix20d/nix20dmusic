from PyQt5 import QtWidgets, QtCore
from PyQt5.QtCore import QCoreApplication
from PyQt5 import QtCore, QtWidgets, QtWidgets
from PyQt5.QtWidgets import (
    QMainWindow, QApplication,
    QLabel, QToolBar, QAction, QStatusBar, QDialog, QFileDialog
)
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import Qt
import ver
import os
import pygame
from about import Ui_Dialog
from find import Ui_Form
from PyQt5.QtWidgets import (QTreeView, QFileSystemModel, QApplication, QMainWindow, QLabel, QWidget,
                             QVBoxLayout, QListWidget)
from PyQt5.QtCore    import QDir
# pygame.mixer.music.load(os.path.basename(file.name))

# pygame.mixer.music.play()

f = open('C:/Users/'+ os.getlogin() +'/Documents/player/path.txt','r')
p = f.read()
f.close()
if p == '' or ' ':
    f = open('C:/Users/'+ os.getlogin() +'/Documents/player/path.txt','w')
    f.write('C:\\Users\\Никита\\Music')
    f.close()
class Player(QtWidgets.QMainWindow, ver.Ui_MainWindow):
    def __init__(self):
        super(Player, self).__init__()

        self.setupUi(self)
        pygame.init()
        self.paused = pygame.mixer.music.get_busy()
        self.listWidget.clicked.connect(self.ch)
        self.pushButton.pressed.connect(self.stop)
        self.pushButton_2.pressed.connect(self.play)
        self.pushButton_3.pressed.connect(self.pause)
        self.pushButton_4.pressed.connect(self.unpause)
        self.actionAbout_author_2.triggered.connect(self.about)
        self.menuFile.triggered.connect(self.finddlg)
        self.s()
    def s(self): #
        f = open('C:/Users/'+ os.getlogin() +'/Documents/player/path.txt','r')
        p = f.read()
        os.chdir(p)
        f.close()
        songtracks = os.listdir()
        for track in songtracks:
            if track.endswith('.mp3'):
                self.listWidget.addItem(track)
    def finddlg(self):
        d = Find(self)
        d.exec()
    def ch(self):
        item = self.listWidget.currentItem()
        pygame.mixer.music.load(str(item.text()))
        pygame.mixer.music.play()
    def play(self):
        pygame.mixer.music.unpause()
    def stop(self):
        pygame.mixer.music.stop()
    def pause(self):
        pygame.mixer.music.pause()
    def unpause(self):
        self.close()
    def about(self):
        dlg = EmployeeDlg(self)
        dlg.exec()
    def __del__(self):
        # print('Inside destructor')
        print(' ')
    def dragEnterEvent(self, event):
        # Тут выполняются проверки и дается (или нет) разрешение на Drop

        mime = event.mimeData()

        # Если перемещаются ссылки
        if mime.hasUrls():
                    # Разрешаем
                event.acceptProposedAction()

    def dropEvent(self, event):
        # Обработка события Drop

        for url in event.mimeData().urls():
            file_name = url.toLocalFile()
            self.listWidget.addItem(file_name)


        return super().dropEvent(event)


class EmployeeDlg(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)

class Find(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui2 = Ui_Form()
        self.ui2.setupUi(self)
        self.ui2.pushButton.pressed.connect(self.find)
    def __del__(self):
        # print('Inside destructor')
        print(' ')
    def find(self):
        global window
        download_path = 'C:'
        global dlg
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        fileName = QFileDialog.getExistingDirectory(self, 'Select a directory', download_path)
    
        f = open('C:/Users/'+ os.getlogin() +'/Documents/player/path.txt','w')
        f.write(fileName)
        f.close()
        self.destroy()
        del window
        window = None
        window = Player()
        window.show()
        # print(os.path.abspath(os.curdir))

            
App = QtWidgets.QApplication([])
window = Player()
window.show()
App.exec()
