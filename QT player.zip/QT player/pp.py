import os
import sys
 
 
_, *files = sys.argv
print(*files, sep="\n")
os.system("pause")