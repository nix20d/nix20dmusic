import os

print('Установка pygame')
os.system('pip install pygame')
print('Установка pyqt5')
os.system('pip install pyqt5')
print('Установка pathlib')
os.system('pip install pathlib')

print('Копирование файлов...')
from pathlib import Path
import shutil
t = 'C:/Users/'+ os.getlogin() +'/Documents/player/'
try:
	shutil.copy('./copy/path.txt',t)
	shutil.copy('./copy/stop_icon.png',t)
	shutil.copy('./copy/close.png',t)
	shutil.copy('./copy/unpause.png',t)
	shutil.copy('./copy/pause.png',t)
except:
	os.mkdir(t)
	shutil.copy('./copy/path.txt',t)
	shutil.copy('./copy/stop_icon.png',t)
	shutil.copy('./copy/close.png',t)
	shutil.copy('./copy/unpause.png',t)
	shutil.copy('./copy/pause.png',t)